<?php
session_start();
unset($_SESSION["user_id"]);
header("Location:http://localhost/site%201/Login_v4/LOGIN.html");
?>